﻿namespace SpacePortals
{
    public enum BallTypes
    {
        Default = 0,
        Magma,
        Rubber,
        Clow,
        Bigger,
        Speedy
    }
}