﻿namespace SpacePortals
{
    public enum TypesInterface
    {
        MainMenu = 0,
        StoreMenu,
        SettingsMenu,
        PlayMenu,
        ResultsMenu
    }
}
