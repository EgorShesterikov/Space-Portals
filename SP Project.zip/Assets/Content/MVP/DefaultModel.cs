﻿namespace SpacePortals
{
    public class DefaultModel : Model
    {

    }
}
