﻿namespace SpacePortals
{
    public enum TypesMusic
    {
        None = 0,
        Default,
    }
}
