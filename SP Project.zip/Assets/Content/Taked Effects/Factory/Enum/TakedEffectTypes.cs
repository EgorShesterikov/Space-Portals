﻿namespace SpacePortals
{
    public enum TakedEffectTypes
    {
        Bomb = 0,
        IncreaseScale,
        IncreaseVelocity,
        ReduceScale,
        ReduceVelocity,
        SpawnBall,
        Star,
        SwapGravity
    }
}