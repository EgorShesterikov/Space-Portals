﻿using UniRx;

namespace SpacePortals
{
    public class SpawnBall : BuffEffect
    {
        protected override void ApplyEffectToBall(Ball ball) { }
    }
}